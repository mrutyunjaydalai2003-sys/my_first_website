package com.gugu.ai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePrefs(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "gugu_secure_settings",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun getApiKey(): String = prefs.getString("gemini_key", "") ?: ""
    fun setApiKey(key: String) { prefs.edit().putString("gemini_key", key.trim()).apply() }
    fun getModel(): String = prefs.getString("gemini_model", "gemini-2.0-flash") ?: "gemini-2.0-flash"
    fun setModel(model: String) { prefs.edit().putString("gemini_model", model).apply() }
}
