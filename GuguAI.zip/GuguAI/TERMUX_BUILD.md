# Termux build guide

> Important: compiling Android apps directly inside Termux is device/repository dependent. Some Termux installs do not provide `openjdk-17` or a complete Android SDK package. Do not use random old repository mirrors.

## 1) Update Termux and install tools

```bash
pkg update && pkg upgrade -y
pkg install -y git wget curl unzip zip nano
pkg search openjdk
```

Install the JDK package actually listed by your configured Termux repositories. On repositories that provide it:

```bash
pkg install -y openjdk-21
java -version
```

If `openjdk-21` is not listed, use `pkg search openjdk` and install the available supported JDK. This project is configured for JDK 17 bytecode; JDK 21 can compile it.

## 2) Put the project in Termux

If the ZIP is in Downloads:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip GuguAI.zip -d ~/GuguAI
cd ~/GuguAI
```

## 3) Install Gradle

```bash
pkg install -y gradle
gradle --version
```

Gradle must be 8.9 or a compatible 8.x release for Android Gradle Plugin 8.7.3. If Termux's packaged Gradle is older/newer and incompatible, build using Android Studio or the GitHub Actions workflow instead.

## 4) Android SDK requirement

A working Android SDK is required, including platform 35 and build-tools. If you already have a usable SDK, set its path:

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"
```

The standard Google Android command-line SDK tools are not officially supported as a turnkey native Termux setup on every phone. If `sdkmanager` is unavailable or SDK installation fails, use Android Studio on a computer or the included GitHub Actions workflow.

## 5) Build

```bash
cd ~/GuguAI
gradle --no-daemon :app:assembleDebug
```

APK output:

```bash
app/build/outputs/apk/debug/app-debug.apk
```

Install from Termux (USB debugging/ADB or Android package installer required):

```bash
termux-open app/build/outputs/apk/debug/app-debug.apk
```

## Common errors

- `Unable to locate package openjdk-17`: run `pkg search openjdk`, install an available supported JDK (for example `openjdk-21` if listed); do not assume `openjdk-17` exists in every repository.
- `termux-change-repo: command not found`: update Termux from the official F-Droid/GitHub source, then use `pkg update`; the helper may not be present in every build. Do not run an unknown mirror script.
- `SDK location not found`: install Android SDK and set `ANDROID_HOME` / `ANDROID_SDK_ROOT`, or build with Android Studio/GitHub Actions.
- `Unsupported Gradle/AGP`: use Gradle 8.9 with AGP 8.7.3.
