package com.gugu.ai.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    suspend fun ask(apiKey: String, model: String, prompt: String, history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Settings में Gemini API key डालें." }
        val contents = JSONArray()
        history.takeLast(12).forEach { (role, text) ->
            contents.put(JSONObject().put("role", if (role == "GUGU") "model" else "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val system = "You are GUGU, a caring, playful, intelligent female AI companion. Be warm and natural, never claim to be human. Reply in the user's language (Hindi, English or Odia). Be concise unless asked for detail. For phone actions, guide the user and never claim an action was completed unless Android confirms it."
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "$system\n\nUser: $prompt"))))
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.8).put("maxOutputTokens", 2048))
            .toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val request = Request.Builder().url(url).post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }.getOrDefault("HTTP ${response.code}")
                throw IllegalStateException(message)
            }
            val json = JSONObject(raw)
            json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
    }
}
