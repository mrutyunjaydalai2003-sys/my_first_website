package com.gugu.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceHelper(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
    fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gugu_reply") }
    fun stop() { tts?.stop() }
    fun setRate(rate: Float) { tts?.setSpeechRate(rate.coerceIn(0.7f, 1.3f)) }
    fun shutdown() { tts?.shutdown(); tts = null }
}
