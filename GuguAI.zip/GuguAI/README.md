# GUGU AI (Android starter project)

A Kotlin + Jetpack Compose Android app with Gemini chat, encrypted local API-key preferences, basic speech input/output, app launching shortcuts, and a coding prompt screen.

## Build requirements
- JDK 17
- Android SDK Platform 35 and Build Tools (Android Studio recommended)
- Gradle 8.9 (Android Gradle Plugin 8.7.3)

## Build in Android Studio
1. Open this folder as an existing project.
2. Let Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Gemini setup
1. Create a Gemini API key in Google AI Studio.
2. Install and open GUGU AI > Settings.
3. Paste the key and select a model.
4. Open Chat and send a message.

## Termux notes
Android SDK/Gradle builds on Termux vary by device and repository. See `TERMUX_BUILD.md`. Android Studio or GitHub Actions is the more reliable build route. The Gradle project targets JDK 17; if the Termux repository does not provide `openjdk-17`, use a supported JDK 21 package and build with a compatible Gradle/AGP setup, or build on a PC/cloud runner.

## Current feature boundaries
- Speech input uses Android's installed speech-recognition service; language availability depends on the device.
- TTS uses the device's installed voices; a female voice is not guaranteed on every device.
- App launching uses Android package launch intents and only works for installed apps.
- No background always-listening wake word, arbitrary screen tapping, notification reading, calls, or SMS automation is enabled in this starter. Those require separate permission flows and platform-specific implementation.
- Gemini calls are standard request/response, not token streaming. Keep the API key private; encrypted preferences protect local storage but do not make a client-side key impossible to extract from a compromised device.
