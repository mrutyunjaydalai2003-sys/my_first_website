package com.gugu.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.gugu.ai.assistant.AppActions
import com.gugu.ai.data.GeminiRepository
import com.gugu.ai.data.SecurePrefs
import com.gugu.ai.voice.VoiceHelper
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080B18)
private val Panel = Color(0xFF141A2E)
private val Cyan = Color(0xFF55E6FF)
private val Purple = Color(0xFF9B7BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GuguApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuguApp() {
    val context = LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    val repo = remember { GeminiRepository() }
    val voice = remember { VoiceHelper(context) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var apiKey by remember { mutableStateOf(prefs.getApiKey()) }
    var model by remember { mutableStateOf(prefs.getModel()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Online • Gemini ready after API setup") }
    val messages = remember { mutableStateListOf<Pair<String, String>>() }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "GUGU से बात करें")
            }
            runCatching { speechLauncher.launch(intent) }.onFailure { status = "Speech recognition उपलब्ध नहीं है" }
        } else status = "Microphone permission जरूरी है"
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, secondary = Purple, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Chat", "Assistant", "Coding", "Settings").forEachIndexed { index, label ->
                    NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = {
                        Icon(when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Chat; 2 -> Icons.Default.AutoAwesome; 3 -> Icons.Default.Code; else -> Icons.Default.Settings }, label)
                    }, label = { Text(label) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Bg).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("GUGU", style = MaterialTheme.typography.headlineMedium, color = Cyan)
                    Text("  AI", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    Text("●", color = Color(0xFF4CE6A1)); Text(" $status", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(16.dp))
                when (tab) {
                    0 -> HomeScreen(onChat = { tab = 1 }, onOpen = { pkg ->
                        status = if (AppActions.openApp(context, pkg)) "App launched" else "App not installed"
                    })
                    1 -> ChatScreen(messages, input, { input = it }, busy,
                        onSend = {
                            val prompt = input.trim()
                            if (prompt.isNotEmpty() && !busy) {
                                messages.add("YOU" to prompt); input = ""; busy = true
                                scope.launch {
                                    try {
                                        val answer = repo.ask(prefs.getApiKey(), prefs.getModel(), prompt, messages.dropLast(1).toList())
                                        messages.add("GUGU" to answer); voice.speak(answer); status = "Reply received"
                                    } catch (e: Exception) { messages.add("GUGU" to "Oops! ${e.message ?: "Something went wrong"}"); status = "Check API / internet" }
                                    busy = false
                                }
                            }
                        }, onMic = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN") }
                                runCatching { speechLauncher.launch(i) }.onFailure { status = "Speech recognition unavailable" }
                            } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }, onStop = { voice.stop() })
                    2 -> AssistantScreen(onOpen = { pkg -> status = if (AppActions.openApp(context, pkg)) "Opened" else "App not installed" }, onSettings = { AppActions.openAndroidSettings(context) })
                    3 -> CodingScreen()
                    else -> SettingsScreen(apiKey, { apiKey = it; prefs.setApiKey(it) }, model, { model = it; prefs.setModel(it) }, onClear = { messages.clear() })
                }
            }
        }
    }
}

@Composable
fun Orb() {
    Box(Modifier.fillMaxWidth().height(235.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(190.dp).background(Brush.radialGradient(listOf(Purple, Color(0xFF243A80), Bg)), CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(130.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(58.dp))
            }
        }
    }
}

@Composable
fun HomeScreen(onChat: () -> Unit, onOpen: (String) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp)); Orb()
        Text("Hey jaan! Main GUGU hoon ❤️", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text("Aaj kya karna hai?", color = Color.LightGray)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onChat, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Chat, null); Text("  Talk to GUGU") }
        Spacer(Modifier.height(16.dp)); Text("QUICK LAUNCH", color = Cyan, modifier = Modifier.align(Alignment.Start))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickButton("YouTube", Modifier.weight(1f)) { onOpen("com.google.android.youtube") }
            QuickButton("WhatsApp", Modifier.weight(1f)) { onOpen("com.whatsapp") }
            QuickButton("Instagram", Modifier.weight(1f)) { onOpen("com.instagram.android") }
        }
        Spacer(Modifier.height(8.dp))
        QuickButton("Chrome", Modifier.fillMaxWidth()) { onOpen("com.android.chrome") }
    }
}

@Composable fun QuickButton(label: String, modifier: Modifier = Modifier, click: () -> Unit) {
    OutlinedButton(onClick = click, modifier = modifier, shape = RoundedCornerShape(14.dp)) { Text(label) }
}

@Composable
fun ChatScreen(messages: List<Pair<String, String>>, input: String, onInput: (String) -> Unit, busy: Boolean, onSend: () -> Unit, onMic: () -> Unit, onStop: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), reverseLayout = false) {
            if (messages.isEmpty()) item { Text("GUGU: Hi jaan! Hindi, English ya Odia mein baat karo. 💜", color = Color.LightGray) }
            items(messages) { (who, text) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = if (who == "GUGU") Panel else Color(0xFF202A45))) {
                    Column(Modifier.padding(12.dp)) { Text(who, color = if (who == "GUGU") Cyan else Purple); Text(text, color = Color.White) }
                }
            }
            if (busy) item { CircularProgressIndicator(color = Cyan, modifier = Modifier.size(24.dp)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, onInput, Modifier.weight(1f), placeholder = { Text("Message GUGU...") }, maxLines = 4)
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, "Voice", tint = Cyan) }
            IconButton(onClick = onSend, enabled = !busy) { Icon(Icons.Default.Send, "Send", tint = Cyan) }
            IconButton(onClick = onStop) { Icon(Icons.Default.Stop, "Stop", tint = Purple) }
        }
    }
}

@Composable
fun AssistantScreen(onOpen: (String) -> Unit, onSettings: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PHONE ASSISTANT", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Text("Tap a shortcut to launch the installed app. Calls and messages are not sent automatically.", color = Color.LightGray)
        listOf("YouTube" to "com.google.android.youtube", "WhatsApp" to "com.whatsapp", "Instagram" to "com.instagram.android", "Chrome" to "com.android.chrome").forEach { (name, pkg) ->
            QuickButton("Open $name", Modifier.fillMaxWidth()) { onOpen(pkg) }
        }
        QuickButton("Open Android Settings", Modifier.fillMaxWidth(), onSettings)
    }
}

@Composable
fun CodingScreen() {
    var request by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CODING MODE", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Text("Describe the code you need. Send it in Chat and GUGU will generate it using Gemini.", color = Color.LightGray)
        OutlinedTextField(request, { request = it }, Modifier.fillMaxWidth(), label = { Text("Example: Python calculator") })
        Text("Tip: Open Chat and ask GUGU to write, debug or explain your code.", color = Color.White)
    }
}

@Composable
fun SettingsScreen(apiKey: String, onKey: (String) -> Unit, model: String, onModel: (String) -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("SETTINGS", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Text("Gemini API configuration", color = Color.White)
        OutlinedTextField(apiKey, onKey, Modifier.fillMaxWidth(), label = { Text("Gemini API Key") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
        Text("Key is stored with Android encrypted preferences on this device.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        Text("Model", color = Color.White)
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }) { Text(model) }
            DropdownMenu(expanded, { expanded = false }) {
                listOf("gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro").forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { onModel(item); expanded = false }) }
            }
        }
        Button(onClick = onClear, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF663B65))) { Text("Clear chat history") }
        Text("GUGU AI v1.0 • Android 8.0+", color = Color.Gray)
    }
}
